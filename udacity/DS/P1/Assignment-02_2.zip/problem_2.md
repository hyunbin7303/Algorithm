Data Strcture : Recursion
I used Recursion for this assignemnt because it's about hierarchical file system.
It just required to find specific extension in the sub directory, so using recursive must be the right solution for this assignment.

Space and time complexity.
Time complexity : O(n)
Since it just needs to step inside for sub-director, it takes O(n).


