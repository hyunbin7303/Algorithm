Algorithm : Recursive
Simply Recursive algorithm can be applied since it's finding specific user in the sub directory.

Space Complexity : O(n).
Whenever group or users are added, it is stored in list; so it can be O(n) in most cases.
   
    
Time complexity : O(n) in general.
 O(n) in general because it needs to itereate each groups through for loop.