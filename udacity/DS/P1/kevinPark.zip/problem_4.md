Algorithm : Recursive
Simply Recursive algorithm can be applied since it's finding specific user in the  



Analysis 
Time complexity : O(n)
Doesn't 