Whenever there is a new node, it needs to find the end, so it uses the same principle of Linked list.
The time complexity for this assignment is O(n).
